# read in the values for each item

# now solve the problem
# good luck :D
